import pandas as pd

# Loading the CSV file
data = pd.read_csv('data.csv')

# Filtering the unique dates from "CUTDATE"
unique_dates = ['30-06-25', '31-07-25']
effort_data = {}

# Checking for effort metrics in columns
effort_columns = [col for col in data.columns if 'effort' in col.lower()]
if effort_columns:
    for date in unique_dates:
        filtered_data = data[data['CUTDATE'] == date]
        effort_metrics = filtered_data[effort_columns].sum()  # Summing up for the month
        effort_data[date] = effort_metrics.to_dict()
    
    print("Effort metrics summary for both months:")
    print(effort_data)
else:
    print("No columns related to 'effort metrics' were found in the dataset.")
