# Read the file 'table_info.txt' to analyze table structure for 'data.csv'

# Opening file to understand structure of data.csv
with open("table_info.txt", "r") as file:
    table_structure = file.read()

print("Table Structure fetched successfully!")
print(table_structure)
