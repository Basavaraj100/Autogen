import pandas as pd

# Load the `data.csv` file
data = pd.read_csv('data.csv')

# Calculate performance (Resolution) for each opening bucket at CUTDATE '31-07-25' and '30-06-25'
performance_results = data[data['CUTDATE'].isin(['31-07-25', '30-06-25'])] \
    .groupby(['CUTDATE', 'OPENING_DPD_BKT'])['PAID_FLAG'].mean()

# Print the results
print("Performance for '31-07-25' and '30-06-25' by OPENING_DPD_BKT level:")
print(performance_results)
