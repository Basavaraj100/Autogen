import pandas as pd

# Load the data
data = pd.read_csv("data.csv")

# Filter for the required months: 'jun25' and 'jul25'
filtered_data = data[data['CUTDATE'].isin(['jun25', 'jul25'])]

# Grouped calculation by 'CUTDATE'
performance = filtered_data.groupby('CUTDATE').apply(lambda group: pd.Series({
    'Resolution': group['PAID_FLAG'].mean(),
    'Collection_Efficiency': group['TOT_COLLECTED_AMT'].sum() / group['TOT_COLLECTABLE_AMT'].sum()
}))

# Display results
print("Performance metrics for Opening Bucket Level for Jun25 and Jul25 are as follows:")
print(performance)
