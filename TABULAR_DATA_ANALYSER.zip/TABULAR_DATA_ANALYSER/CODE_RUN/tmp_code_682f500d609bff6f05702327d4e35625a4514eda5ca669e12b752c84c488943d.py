# Step 1: Check the table structure in 'table_info.txt'
with open('table_info.txt', 'r', encoding='utf-8') as f:
    file_content = f.read()
    print(file_content)

# Assuming the table_info.txt confirms the column names and their structure,
# Step 2: Now, process the CSV to get the performance value for '30-06-25'
import pandas as pd

# Load the data
data = pd.read_csv('data.csv')

# Filter the data for the date '30-06-25'
target_date = '30-06-25'
performance_value = data.loc[data['date'] == target_date, 'performance'].values

# Print the performance value
if len(performance_value) > 0:
    print(f"The performance value for {target_date} is {performance_value[0]}.")
else:
    print(f"No performance value found for {target_date}.")
