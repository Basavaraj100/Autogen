# Read the table_info.txt file to get an understanding of the table structure
def read_text_file(file_path):
    with open(file_path, 'r') as file:
        data = file.read()
    return data

# Fetch the table information
table_info = read_text_file('table_info.txt')
print("Table Information:")
print(table_info)
print("\nThe table_info.txt has been read successfully.")
