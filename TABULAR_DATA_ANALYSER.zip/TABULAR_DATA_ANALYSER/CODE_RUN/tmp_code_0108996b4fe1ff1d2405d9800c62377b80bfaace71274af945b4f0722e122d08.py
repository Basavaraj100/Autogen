import pandas as pd

# Load the CSV data
data = pd.read_csv('data.csv')

# Display the first few rows of the dataset to inspect the CUTDATE column
print(data['CUTDATE'].head())

# Print the unique dates to understand the available entries in the CUTDATE column
print("Unique dates in CUTDATE column:")
print(data['CUTDATE'].unique())

print("Please verify the dates to ensure they are consistent with '2025-06-25' and '2025-07-25' or share the correct format if needed.")
