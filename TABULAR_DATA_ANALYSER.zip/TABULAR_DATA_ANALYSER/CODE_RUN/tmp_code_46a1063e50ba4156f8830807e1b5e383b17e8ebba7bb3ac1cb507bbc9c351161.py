import pandas as pd

# Load the dataset
data_path = 'data.csv'
data = pd.read_csv(data_path)

# Filter data for the specific date '30-6-25'
filtered_data = data[data['CUTDATE'] == '30-06-25']

# Group by 'OPENING_DPD_BKT' and compute performance metrics
grouped_data = filtered_data.groupby('OPENING_DPD_BKT').agg(
    Total_Collectable_Amount=('TOT_COLLECTABLE_AMT', 'sum'),
    Total_Collected_Amount=('TOT_COLLECTED_AMT', 'sum'),
    Accounts=('AGMTNO', 'count')  # Number of agreements/accounts
).reset_index()

# Calculate collection efficiency/performance for opening bucket levels
grouped_data['Performance (%)'] = (grouped_data['Total_Collected_Amount'] / grouped_data['Total_Collectable_Amount']) * 100

# Display the final results
print("Performance at Opening Bucket Level for '30-6-25':")
print(grouped_data)
