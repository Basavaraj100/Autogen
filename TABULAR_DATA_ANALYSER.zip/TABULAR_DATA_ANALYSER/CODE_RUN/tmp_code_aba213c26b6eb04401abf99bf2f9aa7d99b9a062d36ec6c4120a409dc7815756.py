import pandas as pd

# Read the data from data.csv
data = pd.read_csv('data.csv')

# Group by 'Pclass' and calculate survival rate
pclass_survival_rate = data.groupby('Pclass')['Survived'].mean()

# Print the resulting survival rates
print("Pclass Survival Rates:")
print(pclass_survival_rate)
print("Task Completed: Pclass-wise survival rates calculated.")
