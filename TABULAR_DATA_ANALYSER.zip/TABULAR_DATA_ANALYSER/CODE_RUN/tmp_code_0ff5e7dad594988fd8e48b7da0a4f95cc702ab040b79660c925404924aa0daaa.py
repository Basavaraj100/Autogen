import pandas as pd

# Load the data
data = pd.read_csv("data.csv")

# Filter data for the required bucket and dates
bucket_data = data[
    (data['OPENING_DPD_BKT'] == '1.BKT 0') & 
    (data['CUTDATE'].isin(['30-06-25', '31-07-25']))
]

# Replace null values in relevant columns with 0 for computation
bucket_data['FIELD_VISIT'] = bucket_data['FIELD_VISIT'].fillna(0)
bucket_data['VISIT_BEFORE10'] = bucket_data['VISIT_BEFORE10'].fillna(0)
bucket_data['VISIT_HAPPENED_FLAG_NEW'] = bucket_data['VISIT_HAPPENED_FLAG_NEW'].fillna(0)

# Grouped calculation by 'CUTDATE'
input_metrics = bucket_data.groupby('CUTDATE').apply(lambda group: pd.Series({
    'Visit_Intensity': group['FIELD_VISIT'].mean(),
    'Early_Visit': group['VISIT_BEFORE10'].mean(),
    'Visit_Coverage': group['VISIT_HAPPENED_FLAG_NEW'].mean()
}))

# Calculate shifts between the dates (difference)
shift_metrics = input_metrics.diff().iloc[1]

# Display input metrics and shifts
print("Input metrics for '1.BKT 0' based on CUTDATE:")
print(input_metrics)
print("\nShift in input metrics between 30-06-25 and 31-07-25:")
print(shift_metrics)
