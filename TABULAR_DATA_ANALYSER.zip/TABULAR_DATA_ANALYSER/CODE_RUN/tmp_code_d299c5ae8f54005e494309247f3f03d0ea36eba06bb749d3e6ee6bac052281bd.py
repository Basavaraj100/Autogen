import pandas as pd

# Load the CSV data
data = pd.read_csv('data.csv')

# Convert the CUTDATE column to a proper datetime format using DD-MM-YY
data['CUTDATE'] = pd.to_datetime(data['CUTDATE'], format='%d-%m-%y')

# Filter data for June 30, 2025 and July 31, 2025
filter_dates = ['2025-06-30', '2025-07-31']  # Adjusted to match the actual unique dates
filtered_data = data[data['CUTDATE'].isin(pd.to_datetime(filter_dates))]

# Calculate collection efficiency for each date
collection_efficiency = (
    filtered_data.groupby('CUTDATE').apply(
        lambda x: x['TOT_COLLECTED_AMT'].sum() / x['TOT_COLLECTABLE_AMT'].sum()
    )
)

# Print the results for both dates
print("Collection efficiency for June 30 and July 31, 2025:")
print(collection_efficiency)
