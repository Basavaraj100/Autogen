import pandas as pd

# Read the CSV file
data = pd.read_csv('data.csv')

# Filter the data for CUTDATE = '30-06-25'
filtered_data = data[data['CUTDATE'] == '30-06-25']

# Calculate performance metrics
# Resolution = Average of PAID_FLAG
resolution = filtered_data['PAID_FLAG'].mean()

# Collection Efficiency = Total collected amount / Total collectable amount
collection_efficiency = filtered_data['TOT_COLLECTED_AMT'].sum() / filtered_data['TOT_COLLECTABLE_AMT'].sum()

# Output Results
print(f"Performance metrics for CUTDATE '30-06-25':")
print(f"Resolution: {resolution}")
print(f"Collection Efficiency: {collection_efficiency}")
