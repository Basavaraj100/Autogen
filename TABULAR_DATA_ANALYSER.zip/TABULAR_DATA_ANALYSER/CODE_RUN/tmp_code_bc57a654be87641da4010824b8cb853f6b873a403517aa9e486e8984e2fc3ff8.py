import pandas as pd

# Read the CSV file
data = pd.read_csv('data.csv')

# Filter the data for the given CUTDATE
filtered_data = data[data['CUTDATE'] == '30-6-25']

# Debugging: Check if the filtered data is empty
if filtered_data.empty:
    print("No data available for CUTDATE '30-6-25'. The filtered dataset is empty.")
else:
    # Debugging: Analyze the filtered dataset and specific columns
    print("Summary of filtered data:")
    print(filtered_data.describe())
    print("\nChecking for non-numeric or missing values in PAID_FLAG, TOT_COLLECTABLE_AMT, and TOT_COLLECTED_AMT columns:")
    print(filtered_data[['PAID_FLAG', 'TOT_COLLECTABLE_AMT', 'TOT_COLLECTED_AMT']].isna().sum())
    print(f"The filtered dataset:\n{filtered_data}")
