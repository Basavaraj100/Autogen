import pandas as pd

try:
    # Load data
    data = pd.read_csv('data.csv')

    # Check for the column "Survived"
    if 'Survived' not in data.columns:
        raise ValueError("The expected 'Survived' column is not in the dataset.")

    # Filter and count the survivors
    num_survived = data['Survived'].sum()

    print(f"The total number of survivors is: {num_survived}")

except Exception as e:
    print(f"An error occurred: {e}")
