import pandas as pd

try:
    # Load data
    data = pd.read_csv('data.csv')

    # Fetch all the column names
    columns = data.columns.tolist()

    # Display the first few rows to infer the meaning of columns
    sample_data = data.head()

    print(f"Columns present in the dataset: {columns}")
    print("\nSample data to infer column meanings:")
    print(sample_data)

except Exception as e:
    print(f"An error occurred: {e}")
