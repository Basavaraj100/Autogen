import pandas as pd

# Loading the CSV file
data = pd.read_csv('data.csv')

# Checking for unique values in the "CUTDATE" column
if 'CUTDATE' in data.columns:
    unique_values = data['CUTDATE'].unique()
    print(f"Unique values in CUTDATE: {unique_values}")
else:
    print("The column 'CUTDATE' does not exist in the dataset.")
