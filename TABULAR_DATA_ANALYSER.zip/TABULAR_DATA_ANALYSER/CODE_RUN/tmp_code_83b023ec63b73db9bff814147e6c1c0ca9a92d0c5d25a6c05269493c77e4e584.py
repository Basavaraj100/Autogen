import pandas as pd

# Load the CSV file
data = pd.read_csv("data.csv")

# Display the column names to debug the structure of the data
print("Column names in the dataset:")
print(data.columns)
