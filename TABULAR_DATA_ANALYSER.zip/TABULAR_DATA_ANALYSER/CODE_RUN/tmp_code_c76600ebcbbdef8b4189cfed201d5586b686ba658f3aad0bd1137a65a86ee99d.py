with open('table_info.txt', 'r', encoding='utf-8') as f:
    file_content = f.read()
    # Checking if the content is available to validate
    if file_content.strip():
        print(file_content)
    else:
        print("The 'table_info.txt' file is empty or content is not properly read.")
