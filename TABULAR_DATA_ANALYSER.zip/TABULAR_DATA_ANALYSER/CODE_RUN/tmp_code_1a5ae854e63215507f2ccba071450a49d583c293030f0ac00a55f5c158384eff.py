import pandas as pd
import matplotlib.pyplot as plt

# Load data from CSV file
data = pd.read_csv('data.csv')

# Filter data for CUTDATE values '30-06-25' and '31-07-25'
filtered_data = data[data['CUTDATE'].isin(['30-06-25', '31-07-25'])]

# Ensure 'PAID_FLAG' is numeric for computation
filtered_data['PAID_FLAG'] = pd.to_numeric(filtered_data['PAID_FLAG'], errors='coerce')

# Group by CUTDATE and OPENING_DPD_BKT, calculate resolution
performance = filtered_data.groupby(['CUTDATE', 'OPENING_DPD_BKT'])['PAID_FLAG'].mean().reset_index()

# Rename columns for clarity
performance.columns = ['CUTDATE', 'OPENING_DPD_BKT', 'Resolution']

# Convert resolution to percentage
performance['Resolution (%)'] = (performance['Resolution'] * 100).round(2)

# Create the bar plot
plt.figure(figsize=(12, 6))
for cutdate in performance['CUTDATE'].unique():
    subset = performance[performance['CUTDATE'] == cutdate]
    plt.bar(subset['OPENING_DPD_BKT'] + f" ({cutdate})", subset['Resolution (%)'], label=cutdate)

# Add labels, title, and legend
plt.xlabel('Opening DPD BKT (and CUTDATE)', fontsize=12)
plt.ylabel('Resolution (%)', fontsize=12)
plt.title('Resolution (%) by Opening DPD BKT for each CUTDATE', fontsize=14)
plt.xticks(rotation=45, ha='right')
plt.legend(title='CUTDATE')
plt.tight_layout()

# Save the figure
plt.savefig("output.png")
print("Bar graph saved as 'output.png'.")
