import pandas as pd

# Load the CSV data into a pandas DataFrame
df = pd.read_csv('data.csv')

# Filter data for the specific CUTDATE ('30-06-25')
filtered_data = df[df['CUTDATE'] == '30-06-25']

# Group data by OPENING_DPD_BKT and compute performance metrics
bucket_performance = filtered_data.groupby('OPENING_DPD_BKT').agg(
    Resolution=('PAID_FLAG', 'mean'),
    Collection_Efficiency=('TOT_COLLECTED_AMT', lambda x: x.sum() / filtered_data['TOT_COLLECTABLE_AMT'].sum())
).reset_index()

# Display the grouped performance metrics
print(f"Opening Bucket Level Performance for 30-06-25:")
print(bucket_performance)
