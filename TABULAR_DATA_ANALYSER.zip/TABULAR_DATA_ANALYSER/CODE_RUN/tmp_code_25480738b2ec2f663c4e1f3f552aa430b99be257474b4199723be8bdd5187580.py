import pandas as pd
import matplotlib.pyplot as plt

# Load the data
data = pd.read_csv("titanic.csv")

# Count the number of Survived (1) and Died (0)
survival_counts = data['Survived'].value_counts()

# Create a bar chart
plt.figure(figsize=(8, 6))
survival_counts.plot(kind='bar', color=['red', 'green'], alpha=0.7)
plt.title("Survived vs Died")
plt.xticks(ticks=[0, 1], labels=["Died", "Survived"], rotation=0)
plt.ylabel("Number of Passengers")
plt.xlabel("Survival Status")
plt.grid(axis="y", linestyle="--", alpha=0.7)

# Save the graph to output.png
plt.savefig("output.png")
print("Bar graph of survival status has been saved as output.png")
