import pandas as pd

# Load the `data.csv` file
data = pd.read_csv('data.csv')

# Extract unique values from the `CUTDATE` column
unique_cutdates = data['CUTDATE'].dropna().unique()

# Print the results
print("Unique CUTDATE values in the data are:", unique_cutdates)
