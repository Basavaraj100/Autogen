with open('table_info.txt', 'r', encoding='utf-8') as f:
    file_content = f.read()
    print(file_content)
