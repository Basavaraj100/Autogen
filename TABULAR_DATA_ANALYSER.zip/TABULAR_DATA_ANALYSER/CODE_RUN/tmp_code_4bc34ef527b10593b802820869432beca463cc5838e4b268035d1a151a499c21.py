import pandas as pd

# Show the first few rows of the data.csv to understand its structure
data_path = 'data.csv'
data = pd.read_csv(data_path)

# Display the first few rows and column names to get an understanding of the dataset
print("First few rows of the dataset:")
print(data.head())

print("\nColumn Names:")
print(data.columns)
