import pandas as pd
import matplotlib.pyplot as plt

# Load the CSV data
df = pd.read_csv('data.csv')

# Filter data for the specific CUTDATE ('30-06-25')
filtered_data = df[df['CUTDATE'] == '30-06-25']

# Group data by OPENING_DPD_BKT and compute metrics
bucket_performance = filtered_data.groupby('OPENING_DPD_BKT').agg(
    Resolution=('PAID_FLAG', 'mean'),
    Collection_Efficiency=('TOT_COLLECTED_AMT', lambda x: x.sum() / filtered_data.groupby('OPENING_DPD_BKT')['TOT_COLLECTABLE_AMT'].sum()[x.name])
).reset_index()

# Convert metrics to percentages with one decimal point
bucket_performance['Resolution'] = (bucket_performance['Resolution'] * 100).round(1)
bucket_performance['Collection_Efficiency'] = (bucket_performance['Collection_Efficiency'] * 100).round(1)

# Plotting
fig, ax = plt.subplots(figsize=(10, 6))

# Bar graph for Collection Efficiency
ax.bar(bucket_performance['OPENING_DPD_BKT'], bucket_performance['Collection_Efficiency'], color='skyblue', label='Collection Efficiency (%)')

# Line graph for Resolution
ax.plot(bucket_performance['OPENING_DPD_BKT'], bucket_performance['Resolution'], color='red', marker='o', label='Resolution (%)')

# Add labels, title, and legend
ax.set_xlabel('Opening DPD Bucket')
ax.set_ylabel('Percentage')
ax.set_title('Resolution and Collection Efficiency for 30-06-25')
ax.legend(loc='upper right')
plt.xticks(rotation=45)  # Rotate x-axis labels for better readability

# Save the plot
plt.savefig('output.png')
print("Graph saved as 'output.png'")
