import pandas as pd

# Load the CSV data
data = pd.read_csv('data.csv')

# Convert the CUTDATE column to datetime for filtering purposes
data['CUTDATE'] = pd.to_datetime(data['CUTDATE'])

# Filter data for June 25 and July 25
filter_dates = ['2025-06-25', '2025-07-25']  # Replace with actual year if different
filtered_data = data[data['CUTDATE'].isin(pd.to_datetime(filter_dates))]

# Calculate collection efficiency for each date
collection_efficiency = (
    filtered_data.groupby('CUTDATE').apply(
        lambda x: x['TOT_COLLECTED_AMT'].sum() / x['TOT_COLLECTABLE_AMT'].sum()
    )
)

# Print the results for both dates
print("Collection efficiency for June 25 and July 25:")
print(collection_efficiency)
