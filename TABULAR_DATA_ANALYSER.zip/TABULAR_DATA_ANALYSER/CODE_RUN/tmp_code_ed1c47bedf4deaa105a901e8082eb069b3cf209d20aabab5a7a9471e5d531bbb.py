import pandas as pd

# Load the data from 'data.csv'
data = pd.read_csv("data.csv")

# Filter rows for the specified dates and bucket
filtered_data = data[(data['date'].isin(['30-6-25', '31-7-25'])) & (data['bucket'] == '1.BKT 0')]

# Extract the "effort metrics"
effort_metrics = filtered_data[['date', 'effort_metrics']]

# Display results
print("Effort Metrics for '30-6-25' and '31-7-25' in bucket '1.BKT 0':")
print(effort_metrics)
