import pandas as pd

# Load the dataset
data = pd.read_csv('data.csv')

# Count the total number of passengers by checking the number of rows
total_passengers = data.shape[0]

# Print the result
print(f"Total number of passengers traveling: {total_passengers}")
print("Task Completed: Total count of passengers calculated.")
