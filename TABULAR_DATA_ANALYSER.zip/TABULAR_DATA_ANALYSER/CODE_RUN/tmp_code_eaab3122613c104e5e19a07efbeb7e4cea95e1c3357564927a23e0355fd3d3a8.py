import pandas as pd
import matplotlib.pyplot as plt

# Load the dataset
data = pd.read_csv('data.csv')

# Group by 'Pclass' and calculate survival rates
pclass_survival_rate = data.groupby('Pclass')['Survived'].mean()

# Plot the survival rates as a bar graph
plt.figure(figsize=(8, 6))
bars = plt.bar(pclass_survival_rate.index, pclass_survival_rate, color=['blue', 'green', 'orange'])

# Add labels on top of each bar in percentage format
for bar in bars:
    height = bar.get_height()
    plt.text(bar.get_x() + bar.get_width()/2, height + 0.02, f'{height * 100:.0f}%', ha='center', fontsize=10)

# Add titles and labels
plt.title('Survival Rate by Pclass')
plt.xlabel('Passenger Class (Pclass)')
plt.ylabel('Survival Rate')
plt.xticks(pclass_survival_rate.index, labels=pclass_survival_rate.index, rotation=0)
plt.ylim(0, 1)  # Set y-axis range to 0-1 since survival rate is a percentage
plt.grid(axis='y', linestyle='--', alpha=0.7)

# Save the plot as output.png
plt.savefig('output.png')
print("Task Completed: Bar graph with percentage labels saved as 'output.png'.")
