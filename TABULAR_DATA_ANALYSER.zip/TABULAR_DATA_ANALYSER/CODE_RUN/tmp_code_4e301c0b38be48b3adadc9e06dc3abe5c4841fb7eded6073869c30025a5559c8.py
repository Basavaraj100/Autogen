import matplotlib.pyplot as plt
import matplotlib.image as mpimg

# Load the saved image
img = mpimg.imread('output.png')

# Display the image
plt.imshow(img)
plt.axis('off')  # Turn off axes for better visualization
plt.show()

print("Task Completed: Displaying the saved plot.")
