import pandas as pd
import matplotlib.pyplot as plt

# Load the Titanic dataset
data = pd.read_csv("titanic.csv")

# Group data by survival status
survival_counts = data["Survived"].value_counts()

# Create a bar chart
plt.figure(figsize=(8, 6))
survival_counts.plot(kind="bar", color=["red", "green"], alpha=0.7)
plt.title("Survival Status on Titanic")
plt.xlabel("Survival Status (0 = Died, 1 = Survived)")
plt.ylabel("Passenger Count")
plt.xticks([0, 1], ["Died", "Survived"], rotation=0)
plt.grid(axis="y", linestyle="--", alpha=0.6)

# Save the graph to an image file
plt.savefig("output.png")

print("The bar chart of survival status has been saved as output.png.")
