import pandas as pd

# Load the CSV data
data = pd.read_csv('data.csv')

# Convert the CUTDATE column to a proper datetime format using DD-MM-YY
data['CUTDATE'] = pd.to_datetime(data['CUTDATE'], format='%d-%m-%y')

# Filter data for June 30, 2025, and July 31, 2025
filter_dates = ['2025-06-30', '2025-07-31']  # Adjusted to match the actual unique dates
filtered_data = data[data['CUTDATE'].isin(pd.to_datetime(filter_dates))]

# Group by CUTDATE and OPENING_DPD_BKT, calculate resolution and collection efficiency
dpd_metrics = filtered_data.groupby(['CUTDATE', 'OPENING_DPD_BKT']).apply(
    lambda x: pd.Series({
        'Resolution (%)': round(x['PAID_FLAG'].mean() * 100, 2),  # Average of PAID_FLAG expressed as %
        'Collection Efficiency (%)': round((x['TOT_COLLECTED_AMT'].sum() / x['TOT_COLLECTABLE_AMT'].sum()) * 100, 2)  # Efficiency in %
    })
).reset_index()

# Display the results in table format
print("Opening DPD BKT level resolution and collection efficiency (in %) for June 30 and July 31, 2025:")
print(dpd_metrics.to_string(index=False))
