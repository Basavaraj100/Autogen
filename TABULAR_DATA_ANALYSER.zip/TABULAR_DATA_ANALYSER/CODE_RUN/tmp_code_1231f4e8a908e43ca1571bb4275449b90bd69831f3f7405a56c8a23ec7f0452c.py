# Reading the table_info.txt file to understand the structure of 'data.csv'
with open('table_info.txt', 'r') as file:
    table_info = file.read()

print("Table information retrieved successfully:\n")
print(table_info)
