import pandas as pd

# Load the data
data = pd.read_csv("data.csv")

# Filter for the required months: 'jun25' and 'jul25'
filtered_data = data[(data['CUTDATE'] == 'jun25') | (data['CUTDATE'] == 'jul25')]

# Verify if the filtered dataset is empty
if filtered_data.empty:
    print("The filtered dataset for 'jun25' and 'jul25' is empty. Please check if the data contains these dates.")
else:
    # Replace null values in relevant columns with 0 for computation
    filtered_data['PAID_FLAG'] = filtered_data['PAID_FLAG'].fillna(0)
    filtered_data['TOT_COLLECTABLE_AMT'] = filtered_data['TOT_COLLECTABLE_AMT'].fillna(0)
    filtered_data['TOT_COLLECTED_AMT'] = filtered_data['TOT_COLLECTED_AMT'].fillna(0)

    # Grouped calculation by 'CUTDATE'
    performance = filtered_data.groupby('CUTDATE').apply(lambda group: pd.Series({
        'Resolution': group['PAID_FLAG'].mean(),
        'Collection_Efficiency': group['TOT_COLLECTED_AMT'].sum() / group['TOT_COLLECTABLE_AMT'].sum() if group['TOT_COLLECTABLE_AMT'].sum() > 0 else 0
    }))

    # Display results
    print("Performance metrics for Opening Bucket Level for Jun25 and Jul25 are as follows:")
    print(performance)
