import pandas as pd

# Read the CSV file
data = pd.read_csv('data.csv')

# Get the unique CUTDATES
unique_cutdates = data['CUTDATE'].unique()

# Display the results
print(f"Unique CUTDATES in the data: {unique_cutdates}")
