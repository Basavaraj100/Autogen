# Filter the data for rows where CUTDATE is '30-06-25'
filtered_data = data[data['CUTDATE'] == '30-06-25']

# Display relevant performance metrics for this subset
result_summary = {
    'Total Entries': len(filtered_data),
    'VISIT_HAPPENED_FLAG_NEW Count': filtered_data['VISIT_HAPPENED_FLAG_NEW'].sum(),
    'VISIT_BEFORE10 Mean': filtered_data['VISIT_BEFORE10'].mean()
}

print("Performance metrics for the date 30-06-25:\n")
for key, value in result_summary.items():
    print(f"{key}: {value}")
