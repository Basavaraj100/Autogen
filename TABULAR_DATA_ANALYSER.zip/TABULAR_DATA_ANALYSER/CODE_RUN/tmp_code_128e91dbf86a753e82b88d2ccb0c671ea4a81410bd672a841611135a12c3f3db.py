import pandas as pd

# Read the CSV file
data = pd.read_csv('data.csv')

# Filter the data for the given CUTDATE
filtered_data = data[data['CUTDATE'] == '30-6-25']

# Calculate performance metrics
# Resolution is the average of PAID_FLAG
resolution = filtered_data['PAID_FLAG'].mean()

# Collection Efficiency is the total collected amount divided by the total collectable amount
collection_efficiency = filtered_data['TOT_COLLECTED_AMT'].sum() / filtered_data['TOT_COLLECTABLE_AMT'].sum()

# Display the results
print(f"Performance metrics for CUTDATE '30-6-25':")
print(f"Resolution: {resolution}")
print(f"Collection Efficiency: {collection_efficiency}")
