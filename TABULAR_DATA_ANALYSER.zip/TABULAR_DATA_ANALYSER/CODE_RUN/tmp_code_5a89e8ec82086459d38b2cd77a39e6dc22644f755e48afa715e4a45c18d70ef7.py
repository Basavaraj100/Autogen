import pandas as pd

# Load the data
data = pd.read_csv("data.csv")

# List unique values in the 'CUTDATE' column
cutdate_values = data['CUTDATE'].unique()

# Display the distinct values
print("Distinct values in the CUTDATE column are as follows:")
print(cutdate_values)
