import pandas as pd

# Load data from CSV file
data = pd.read_csv('data.csv')

# Extract unique values from the "CUTDATE" column
unique_cutdate_values = data['CUTDATE'].unique()

# Print unique values of CUTDATE
print(f"Unique values in CUTDATE column: {unique_cutdate_values}")
