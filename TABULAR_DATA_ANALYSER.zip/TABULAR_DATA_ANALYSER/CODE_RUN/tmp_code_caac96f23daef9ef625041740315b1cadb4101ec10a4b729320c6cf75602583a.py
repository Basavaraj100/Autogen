import pandas as pd

# Step 1: Load the CSV file
data = pd.read_csv('data.csv')

# Step 2: Filter data for the specified CUTDATE ('30-6-25')
filtered_data = data[data['CUTDATE'] == '30-6-25']

# Step 3: Calculate performance metrics
# Resolution: Average of PAID_FLAG (handling nulls as 0)
filtered_data['PAID_FLAG'] = filtered_data['PAID_FLAG'].fillna(0)
resolution = filtered_data['PAID_FLAG'].mean()

# Collection Efficiency: Sum(TOT_COLLECTED_AMT) / Sum(TOT_COLLECTABLE_AMT)
total_collected = filtered_data['TOT_COLLECTED_AMT'].sum()
total_collectable = filtered_data['TOT_COLLECTABLE_AMT'].sum()
collection_efficiency = total_collected / total_collectable if total_collectable > 0 else 0

# Step 4: Print the results
print(f"Performance Metrics for '30-6-25':")
print(f"Resolution: {resolution:.2f}")
print(f"Collection Efficiency: {collection_efficiency:.2%}")
print("Task is completed successfully.")
