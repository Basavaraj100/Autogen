import pandas as pd

# Step 1: Load the CSV file
data = pd.read_csv('data.csv')

# Step 2: Filter data for the specified CUTDATE ('30-6-25')
filtered_data = data[data['CUTDATE'] == '30-6-25']

# Step 3: Check if data exists for the given date
if filtered_data.empty:
    print("No data available for '30-6-25'. Please verify the CUTDATE value.")
else:
    # Data exists, proceed with calculations

    # Resolution: Average of PAID_FLAG (handling nulls as 0)
    filtered_data['PAID_FLAG'] = pd.to_numeric(filtered_data['PAID_FLAG'], errors='coerce').fillna(0)
    resolution = filtered_data['PAID_FLAG'].mean()

    # Collection Efficiency: Sum(TOT_COLLECTED_AMT) / Sum(TOT_COLLECTABLE_AMT)
    total_collected = filtered_data['TOT_COLLECTED_AMT'].sum()
    total_collectable = filtered_data['TOT_COLLECTABLE_AMT'].sum()
    collection_efficiency = total_collected / total_collectable if total_collectable > 0 else 0

    # Print the results
    print(f"Performance Metrics for '30-6-25':")
    print(f"Resolution: {resolution:.2f}")
    print(f"Collection Efficiency: {collection_efficiency:.2%}")

print("Task is completed successfully.")
