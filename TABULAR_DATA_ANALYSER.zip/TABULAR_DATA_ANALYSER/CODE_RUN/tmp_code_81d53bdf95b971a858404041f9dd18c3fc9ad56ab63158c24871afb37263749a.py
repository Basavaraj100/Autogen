import pandas as pd

# Load the CSV data
data = pd.read_csv('data.csv')

# Convert the CUTDATE column to a proper datetime format using DD-MM-YY
data['CUTDATE'] = pd.to_datetime(data['CUTDATE'], format='%d-%m-%y')

# Filter data for June 30, 2025, and July 31, 2025
filter_dates = ['2025-06-30', '2025-07-31']  # Adjusted to match the actual unique dates
filtered_data = data[data['CUTDATE'].isin(pd.to_datetime(filter_dates))]

# Group by CUTDATE and OPENING_DPD_BKT, calculate performance and effort metrics
dpd_metrics = filtered_data.groupby(['CUTDATE', 'OPENING_DPD_BKT']).apply(
    lambda x: pd.Series({
        'Resolution (%)': round(x['PAID_FLAG'].mean() * 100, 2),  # Average of PAID_FLAG in percentage
        'Collection Efficiency (%)': round((x['TOT_COLLECTED_AMT'].sum() / x['TOT_COLLECTABLE_AMT'].sum()) * 100, 2),  # Efficiency in %
        'Visit Intensity': round(x['FIELD_VISIT'].mean(), 2),  # Average FIELD_VISIT
        'Early Visit (%)': round(x['VISIT_BEFORE10'].mean() * 100, 2),  # Average of VISIT_BEFORE10 in percentage
        'Visit Coverage (%)': round(x['VISIT_HAPPENED_FLAG_NEW'].mean() * 100, 2)  # Average of VISIT_HAPPENED_FLAG_NEW in percentage
    })
).reset_index()

# Separate metrics for June and July
june_dpd_metrics = dpd_metrics[dpd_metrics['CUTDATE'] == '2025-06-30']
july_dpd_metrics = dpd_metrics[dpd_metrics['CUTDATE'] == '2025-07-31']

# Merge June and July metrics for comparison
comparison = pd.merge(june_dpd_metrics, july_dpd_metrics, on='OPENING_DPD_BKT', suffixes=('_June', '_July'))

# Calculate the shifts in effort metrics
comparison['Visit Intensity Shift'] = comparison['Visit Intensity_July'] - comparison['Visit Intensity_June']
comparison['Early Visit Shift (%)'] = comparison['Early Visit (%)_July'] - comparison['Early Visit (%)_June']
comparison['Visit Coverage Shift (%)'] = comparison['Visit Coverage (%)_July'] - comparison['Visit Coverage (%)_June']

# Select and display relevant columns
result = comparison[[
    'OPENING_DPD_BKT', 
    'Resolution (%)_June', 'Collection Efficiency (%)_June', 'Visit Intensity_June', 'Early Visit (%)_June', 'Visit Coverage (%)_June',
    'Resolution (%)_July', 'Collection Efficiency (%)_July', 'Visit Intensity_July', 'Early Visit (%)_July', 'Visit Coverage (%)_July',
    'Visit Intensity Shift', 'Early Visit Shift (%)', 'Visit Coverage Shift (%)'
]]

print("Opening DPD BKT level performance and effort metrics for June 30 and July 31, 2025, with shifts in effort metrics:")
print(result.to_string(index=False))
