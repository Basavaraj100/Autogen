import pandas as pd

# Load the CSV data into a pandas DataFrame
df = pd.read_csv('data.csv')

# Filter data for the specific CUTDATE ('30-06-25')
filtered_data = df[df['CUTDATE'] == '30-06-25']

# Compute the metrics
resolution = filtered_data['PAID_FLAG'].mean()
collection_efficiency = filtered_data['TOT_COLLECTED_AMT'].sum() / filtered_data['TOT_COLLECTABLE_AMT'].sum()
visit_intensity = filtered_data['FIELD_VISIT'].mean()
early_visit = filtered_data['VISIT_BEFORE10'].mean()
visit_coverage = filtered_data['VISIT_HAPPENED_FLAG_NEW'].mean()

# Display the results
print(f"Performance Metrics for 30-06-25:")
print(f"Resolution: {resolution}")
print(f"Collection Efficiency: {collection_efficiency}")
print(f"Effort Metrics for 30-06-25:")
print(f"Visit Intensity: {visit_intensity}")
print(f"Early Visit (before 10th): {early_visit}")
print(f"Visit Coverage: {visit_coverage}")
