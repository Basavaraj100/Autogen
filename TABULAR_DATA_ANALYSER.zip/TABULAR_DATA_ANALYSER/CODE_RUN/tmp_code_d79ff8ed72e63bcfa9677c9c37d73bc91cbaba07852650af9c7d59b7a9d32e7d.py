import pandas as pd

# Load the CSV data
data = pd.read_csv('data.csv')

# Convert the CUTDATE column to a proper datetime format using DD-MM-YY
data['CUTDATE'] = pd.to_datetime(data['CUTDATE'], format='%d-%m-%y')

# Filter data for June 30, 2025, and July 31, 2025
filter_dates = ['2025-06-30', '2025-07-31']  # Adjusted to match the actual unique dates
filtered_data = data[data['CUTDATE'].isin(pd.to_datetime(filter_dates))]

# Group by CUTDATE and calculate effort metrics
effort_metrics = filtered_data.groupby('CUTDATE').apply(
    lambda x: pd.Series({
        'Visit Intensity': x['FIELD_VISIT'].mean(),  # Average FIELD_VISIT
        'Early Visit (%)': x['VISIT_BEFORE10'].mean() * 100,  # Average of VISIT_BEFORE10 in percentage
        'Visit Coverage (%)': x['VISIT_HAPPENED_FLAG_NEW'].mean() * 100  # Average of VISIT_HAPPENED_FLAG_NEW in percentage
    })
).reset_index()

# Display the shifts in effort metrics between the dates
june_metrics = effort_metrics[effort_metrics['CUTDATE'] == '2025-06-30'].iloc[0]
july_metrics = effort_metrics[effort_metrics['CUTDATE'] == '2025-07-31'].iloc[0]

shifts = {
    "Metric": ["Visit Intensity", "Early Visit (%)", "Visit Coverage (%)"],
    "June 30, 2025": [june_metrics['Visit Intensity'], june_metrics['Early Visit (%)'], june_metrics['Visit Coverage (%)']],
    "July 31, 2025": [july_metrics['Visit Intensity'], july_metrics['Early Visit (%)'], july_metrics['Visit Coverage (%)']],
    "Shift": [july_metrics['Visit Intensity'] - june_metrics['Visit Intensity'],
              july_metrics['Early Visit (%)'] - june_metrics['Early Visit (%)'],
              july_metrics['Visit Coverage (%)'] - june_metrics['Visit Coverage (%)']]
}

# Create a DataFrame from the shifts
shifts_df = pd.DataFrame(shifts)

print("Shifts in Effort Metrics Between June 30, 2025, and July 31, 2025:")
print(shifts_df.to_string(index=False))
