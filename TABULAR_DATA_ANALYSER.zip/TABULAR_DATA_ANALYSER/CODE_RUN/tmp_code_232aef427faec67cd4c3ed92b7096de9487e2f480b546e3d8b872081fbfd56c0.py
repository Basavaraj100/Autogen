import pandas as pd

# Loading the CSV file
data = pd.read_csv('data.csv')

# Filtering rows for CUTDATE '30-06-25'
filter_date = '30-06-25'
filtered_data = data[data['CUTDATE'] == filter_date]

# Checking if there is a column named 'performance'
if 'performance' in filtered_data.columns:
    performance = filtered_data['performance']
    print(f"Performance on '{filter_date}':\n{performance}")
else:
    print("The column 'performance' does not exist in the dataset.")
