import pandas as pd
import matplotlib.pyplot as plt

# Load the CSV file
data = pd.read_csv('titanic.csv')

# Group by 'Survived' and count occurrences
survival_counts = data['Survived'].value_counts()

# Plot the bar graph
plt.figure(figsize=(8, 6))
survival_counts.plot(kind='bar', color=['red', 'green'], alpha=0.7)
plt.title('Counts of Survived vs Died')
plt.xlabel('Survival (0 = Died, 1 = Survived)')
plt.ylabel('Count')
plt.xticks([0, 1], ['Died', 'Survived'], rotation=0)
plt.grid(axis='y', linestyle='--', alpha=0.7)

# Save the figure
plt.savefig('output.png')

print("Graph has been saved as 'output.png'. Task Completed.")
