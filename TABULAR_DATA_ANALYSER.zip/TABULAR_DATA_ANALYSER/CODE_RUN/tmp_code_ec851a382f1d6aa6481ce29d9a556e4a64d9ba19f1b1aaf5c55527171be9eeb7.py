# Step 1: Check the table structure in 'table_info.txt'
with open('table_info.txt', 'r', encoding='utf-8') as f:
    file_content = f.read()
    print(file_content)

# Step 2: Calculate Collection Efficiency for '30-06-25'
import pandas as pd

# Load the data
data = pd.read_csv('data.csv')

# Filter the data for the date '30-06-25'
target_date = '30-06-25'
filtered_data = data[data['CUTDATE'] == target_date]

# Check if data is available for the specified date
if not filtered_data.empty:
    total_collected = filtered_data['TOT_COLLECTED_AMT'].sum()
    total_collectable = filtered_data['TOT_COLLECTABLE_AMT'].sum()
    
    # Calculate Collection Efficiency
    if total_collectable > 0:
        collection_efficiency = total_collected / total_collectable
        print(f"The Collection Efficiency for {target_date} is {collection_efficiency:.2f}.")
    else:
        print(f"Total collectable amount is zero for {target_date}; cannot calculate Collection Efficiency.")
else:
    print(f"No data available for CUTDATE = {target_date}.")
