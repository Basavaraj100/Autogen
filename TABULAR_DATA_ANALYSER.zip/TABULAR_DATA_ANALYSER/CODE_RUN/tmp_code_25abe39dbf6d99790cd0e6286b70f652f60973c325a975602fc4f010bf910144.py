import pandas as pd

# Load data from CSV file
data = pd.read_csv('data.csv')

# Filter data for CUTDATE values '30-06-25' and '31-07-25'
filtered_data = data[data['CUTDATE'].isin(['30-06-25', '31-07-25'])]

# Ensure 'PAID_FLAG' is numeric for computation
filtered_data['PAID_FLAG'] = pd.to_numeric(filtered_data['PAID_FLAG'], errors='coerce')

# Group by CUTDATE and OPENING_DPD_BKT, calculate resolution
performance = filtered_data.groupby(['CUTDATE', 'OPENING_DPD_BKT'])['PAID_FLAG'].mean().reset_index()

# Rename columns for clarity
performance.columns = ['CUTDATE', 'OPENING_DPD_BKT', 'Resolution']

# Convert resolution to percentage and format to 2 decimal places
performance['Resolution (%)'] = (performance['Resolution'] * 100).round(2)

# Drop the original resolution column for clarity in output
performance = performance.drop(columns=['Resolution'])

# Print performance data with percentages
print("Performance metrics in percentage (Resolution) at each OPENING_DPD_BKT level for CUTDATE values:")
print(performance)
