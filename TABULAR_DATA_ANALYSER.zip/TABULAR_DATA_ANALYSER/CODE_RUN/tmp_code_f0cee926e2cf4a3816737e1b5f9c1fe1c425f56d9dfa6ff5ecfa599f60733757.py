import pandas as pd

# Load and preview the first few rows of the CSV file
try:
    data = pd.read_csv('data.csv')
    print("Data loaded successfully. Here's a preview:\n")
    print(data.head())
except Exception as e:
    print(f"An error occurred while loading the CSV file: {e}")
