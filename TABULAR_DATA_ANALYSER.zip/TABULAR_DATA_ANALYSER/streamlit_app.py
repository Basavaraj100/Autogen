import streamlit as st
import asyncio
import os
from team.analyzer_gpt import getDataAnalyzerTeam
from config.commandline_utils import getLocalCommandLineExecutor
from autogen_agentchat.messages import TextMessage
from autogen_agentchat.base import TaskResult
from config.openai_model_client import get_model_client


st.title('Analyzer GPT - Digital Data Analyzer')
# st.balloons()

uploaded_file = st.file_uploader('Upload your CSV file',type='csv')

table_info=st.text_area('Enter table info')

if 'messages' not in st.session_state:
    st.session_state.messages = []
if 'autogen_team_state' not in st.session_state:
    st.session_state.autogen_team_state = None

# # task = st.text_input("Enter your task",value = 'Can you give me number of columns in my data (file is data.csv)')

task = st.chat_input("Enter your Task.")

# final_task=f'''Using the table info answer to the user questions 
# table info: {table_info}

# user question : {task} '''


# st.markdown(task)
# st.markdown(task)


async def run_analyzer_gpt(docker,openai_model_client,task):

    try:
        # await start_docker_container(docker)
        team = getDataAnalyzerTeam(docker,openai_model_client)

        if st.session_state.autogen_team_state is not None:
            await team.load_state(st.session_state.autogen_team_state)
        
        
        async for message in team.run_stream(task=task):
            if isinstance(message,TextMessage):
                print(msg := f"{message.source} : {message.content}")
                # yield msg
                if msg.startswith('user'):
                    with st.chat_message('user',avatar='👨'):
                        st.markdown(msg)
                elif msg.startswith('Data_Analyzer_Agent'):
                    with st.chat_message('Data Analyst',avatar='🤖'):
                        st.markdown(msg)                
                elif msg.startswith('CodeExecutor'):
                    with st.chat_message('Code Runner',avatar='🧑🏻‍💻'):
                        st.markdown(msg)
                st.session_state.messages.append(msg)    #  appending msg

            elif isinstance(message,TaskResult):
                print(msg:= f"Stop Reason: {message.stop_reason}")
                # yield msg
                st.markdown(msg)
                st.session_state.messages.append(msg)

        st.session_state.autogen_team_state = await team.save_state()
        return None
    except Exception as e:
        print(e)
        return e
    # finally:
    #     await stop_docker_container(docker)

# displaying older conversations                
if st.session_state.messages:
    for msg in st.session_state.messages:
        st.markdown(msg)


#-------- Once after task gave
if task:
    if uploaded_file is not None and task  :
        
        if not os.path.exists('CODE_RUN'):
            os.makedirs('CODE_RUN')
        # Save the csv file
        with open('CODE_RUN/data.csv','wb') as f:
            f.write(uploaded_file.getbuffer())

        #     # Save the text file 
        if table_info.strip():  # Check if there's any content
            with open('CODE_RUN/table_info.txt', 'w', encoding='utf-8') as f:
                f.write(table_info)

    
    openai_model_client =get_model_client()
    docker = getLocalCommandLineExecutor()


    error = asyncio.run(run_analyzer_gpt(docker,openai_model_client,task))

    if error:
        st.error(f"An error occurred: {error}")

    # if os.path.exists('CODE_RUN/output.png'):
    #     st.image('CODE_RUN/output.png',caption='Analysis File')
    
else:
    st.warning("Please upload the csv file")

