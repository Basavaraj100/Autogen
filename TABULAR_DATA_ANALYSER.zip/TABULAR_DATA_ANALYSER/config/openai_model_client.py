from autogen_ext.models.openai import OpenAIChatCompletionClient,AzureOpenAIChatCompletionClient
from dotenv import load_dotenv
import os

load_dotenv()

api_key ='2E0H9pZ8f4XCZLQaZE1DMIY0NcsuGUeiWUIDj7Ge2xoHu3HFYAa0JQQJ99BCAC77bzfXJ3w3AAABACOGb8ZA'


def get_model_client():
    # model_client = OpenAIChatCompletionClient(model='gpt-4',api_key=api_key)
    model_client = AzureOpenAIChatCompletionClient(
        # azure_deployment="Basavaraj-Bijali",  # This is your deployment name, not the model name
        model="gpt-4o",  # Model name, e.g., "gpt-4"
        api_version="2024-12-01-preview",  # Use the API version your deployment supports
        azure_endpoint="https://tvscs-az-openai.openai.azure.com/",
        api_key=api_key
    )

    return model_client