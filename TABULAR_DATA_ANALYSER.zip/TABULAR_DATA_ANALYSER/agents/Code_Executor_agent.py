# https://microsoft.github.io/autogen/stable/reference/python/autogen_agentchat.agents.html#autogen_agentchat.agents.CodeExecutorAgent

from autogen_agentchat.agents import CodeExecutorAgent
import asyncio
from autogen_agentchat.messages import TextMessage
from autogen_core import CancellationToken
# from autogen_ext.code_executors.docker import DockerCommandLineCodeExecutor
from autogen_ext.code_executors.local import LocalCommandLineCodeExecutor


def getCodeExecutorAgent(code_executor):

    code_executor_agent = CodeExecutorAgent(
        name='CodeExecutor',
        code_executor = code_executor
    )

    return code_executor_agent


# async def main():

#     commandline=LocalCommandLineCodeExecutor(
#     work_dir='CODE_RUN',
#     timeout=120,
#     # allow_files=True,
#     # interpreter_mode='auto'
# )


#     code_executor_agent = getCodeExecutorAgent(code_executor=commandline)

#     task = TextMessage(
#         content=''' Here is the Python Code which You have to run.
# ```python
# a=[1,2,3,4,5]
# for num in a:
#     print(num**2)````        
# ''',
#     source='User'
#     )


#     try:
#         # await docker.start()

#         res = await code_executor_agent.run(
#             task=task,
#         )
#         print('result is :',res.messages[-1].content)
#         # print(type(res))


#     except Exception as e:
#         print(e)
#     # finally:
#     #     await docker.stop()

# if (__name__ == '__main__'):
#     asyncio.run(main())

    